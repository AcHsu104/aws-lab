#!/bin/bash
service httpd stop
